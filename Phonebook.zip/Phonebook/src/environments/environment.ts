// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
 firebaseConfig: {
  // Initialize Firebase
  
    apiKey: "AIzaSyDlSfL4ZMFrM46hkqdgs4aIRoV7Yy7_cH0",
    authDomain: "travelagency-be69c.firebaseapp.com",
    databaseURL: "https://travelagency-be69c.firebaseio.com",
    projectId: "travelagency-be69c",
    storageBucket: "travelagency-be69c.appspot.com",
    messagingSenderId: "444684269120"
  }
 
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
